import numpy as np
import pandas as pd


def get_top_n_recommendations(
    predictions_df: pd.DataFrame,
    user_col: str = "user_id",
    item_col: str = "book_id",
    rating_col: str = "rating",
    n: int = 10,
) -> dict:
    """
    Get the top-N recommendations for each user from a predictions dataframe.

    Args:
        predictions_df (pd.DataFrame): DataFrame with user, item, and rating columns.
        user_col (str): Name of the user ID column.
        item_col (str): Name of the item ID column.
        rating_col (str): Name of the rating/prediction column.
        n (int): The number of recommendations to output for each user.

    Returns:
        A dict where keys are user IDs and values are lists of tuples:
        [(item ID, estimated rating), ...]
    """
    top_n = {}
    for user_id, group in predictions_df.groupby(user_col):
        top_n[user_id] = list(
            group.nlargest(n, rating_col)[[item_col, rating_col]].itertuples(
                index=False, name=None
            )
        )
    return top_n


def calculate_ndcg(
    top_n: dict,
    test_df: pd.DataFrame,
    user_col: str = "user_id",
    item_col: str = "book_id",
    rating_col: str = "rating",
    n: int = 10,
) -> float:
    """
    Calculate the NDCG@k for the recommendations.

    Args:
        top_n (dict): Top-N recommendations for each user.
        test_df (pd.DataFrame): The test dataframe with ground truth ratings.
        user_col (str): Name of the user ID column.
        item_col (str): Name of the item ID column.
        rating_col (str): Name of the rating column in the test set.
        n (int): The value of k for NDCG@k.

    Returns:
        float: The average NDCG@k score.
    """
    ndcg_scores = []
    relevance_threshold = 3.5

    for uid, user_ratings in top_n.items():
        ground_truth = test_df[
            (test_df[user_col] == uid) & (test_df[rating_col] > relevance_threshold)
        ]
        if ground_truth.empty:
            continue

        # DCG calculation
        dcg = 0
        # Convert to list to avoid potential linter errors with .values
        ground_truth_items = ground_truth[item_col].tolist()
        for i, (iid, _) in enumerate(user_ratings):
            if iid in ground_truth_items:
                dcg += 1 / np.log2(i + 2)

        # IDCG calculation
        idcg = sum([1 / np.log2(i + 2) for i in range(min(len(ground_truth), n))])

        ndcg = dcg / idcg if idcg > 0 else 0
        ndcg_scores.append(ndcg)

    return float(np.mean(ndcg_scores)) if ndcg_scores else 0.0
